package ucsal;
import java.util.Date;

import Ucsal1.Paciente;
import Ucsal1.ProfissionalSaude;

public class Agendamento {

 private int Id;
 private Paciente paciente;
 private String especialidade;
 private ProfissionalSaude profissionalSaude;
 private String Convenio;
 private String TipoAtendimento;
 private String Local;
 private Date DataAtendimento;
 private String Situacao;
 private boolean status;
 
 
 
 
 //Construtor
 public Agendamento(
  int Id,
  Paciente paciente,
  String especialidade,
  ProfissionalSaude profissionalSaude,
  String Convenio,
  String TipoAtendimento,
  String convenioOuParticular,
  Date DataAtendimento,
  String Local,
  String Situacao) {
 
 this.Id = Id;
 this.paciente = paciente;
 this.profissionalSaude = profissionalSaude;
 this.Convenio = Convenio;
 this.TipoAtendimento = TipoAtendimento;
 this.Local = Local;
 this.DataAtendimento = DataAtendimento;
 this.Situacao = Situacao;
 
 }



 //Getters and Setters
 public int getId() {
  return Id;
 }
 public void setId(int id) {
  Id = id;
 }



 public Paciente getPaciente() {
  return paciente;
 }
 public void setPaciente(Paciente paciente) {
  this.paciente = paciente;
 }



 public String getEspecialidade() {
  return especialidade;
 }
 public void setEspecialidade(String especialidade) {
  this.especialidade = especialidade;
 }



 public ProfissionalSaude getProfissionalSaude() {
  return profissionalSaude;
 }
 public void setProfissionalSaude(ProfissionalSaude profissionalSaude) {
  this.profissionalSaude = profissionalSaude;
 }



 public String getConvenio() {
  return Convenio;
 }
 public void setConvenio(String convenio) {
  Convenio = convenio;
 }



 public String getTipoAtendimento() {
  return TipoAtendimento;
 }
 public void setTipoAtendimento(String tipoAtendimento) {
  TipoAtendimento = tipoAtendimento;
 }



 public String getLocal() {
  return Local;
 }
 public void setLocal(String local) {
  Local = local;
 }



 public Date getDataAtendimento() {
  return DataAtendimento;
 }
 public void setDataAtendimento(Date dataAtendimento) {
  DataAtendimento = dataAtendimento;
 }



 public String getSituacao() {
  return Situacao;
 }
 public void setSituacao(String situacao) {
  Situacao = situacao;
 }



public boolean isStatus() {
	return status;
}
public void setStatus(boolean status) {
	this.status = status;
	}
}
