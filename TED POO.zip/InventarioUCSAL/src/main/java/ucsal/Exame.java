package ucsal;

import java.util.Date;

public class Exame {

private int id;
private String nome,
			   descricao,
			   observacao,
			   categoria;
private Date dataCadastro;
private boolean status;
	
	//Construtor
	public Exame(int id, String nome, String descricao, String observacao, String categoria, boolean status) {
		this.id = id;
		this.nome = nome;
		this.setDescricao(descricao);
		this.observacao = observacao;
		this.categoria = categoria;
		this.dataCadastro = new Date();
		this.status = true;
	}


	public Exame(int i, Object object, int j, Object object2, Object object3, Object object4, Object object5, int k) {
		// TODO Auto-generated constructor stub
	}



	// Getters e Setters
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	
	
	public String getObservacao() {
		return observacao;
	}
	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}
	
	
	
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	
	
	public Date getDataCadastro() {
		return dataCadastro;
	}
	public void setDataCadastro(Date dataCadastro) {
		this.dataCadastro = dataCadastro;
	}
	
	
	
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}




	
}
