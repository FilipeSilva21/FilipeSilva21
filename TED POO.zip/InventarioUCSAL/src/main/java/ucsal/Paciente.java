package ucsal;

import Ucsal1.Pessoa;

public class Paciente extends Pessoa {
	
	private double contato;
	private String rua,
				   bairro,
				   cidade,
				   estado;
	private int cep;
	private int QtdAtendimentos;
	
	
	//Construtor
	public Paciente(int id, String nome, int contato, String rua, String bairro, String cidade, String estado, int cep) {
		super(id, nome, contato);
		this.rua = rua;
		this.bairro = bairro;
		this.cidade = cidade;
		this.estado = estado;
		this.cep = cep;
	}
	
	// Getters e Setters
	public double getContato() {
		return contato;
	}
	public void setContato(int contato) {
		this.contato = contato;
	}
	
	
	public String getRua() {
		return rua;
	}
	public void setRua(String rua) {
		this.rua = rua;
	}
	
	
	public String getBairro() {
		return bairro;
	}
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	
	
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	
	
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	
	public int getCep() {
		return cep;
	}
	public void setCep(int cep) {
		this.cep = cep;
	}

	
	public int getQtdAtendimentos() {
		return QtdAtendimentos;
	}
	public void setQtdAtendimentos(int qtdAtendimentos) {
		QtdAtendimentos = qtdAtendimentos;
	}
}

