package ucsal;

import java.util.Date;
import java.util.List;

import Ucsal1.Exame;
import Ucsal1.Paciente;
import Ucsal1.ProfissionalSaude;

public class Prontuario {
	 private String identificador;
	    private Paciente paciente;
	    private ProfissionalSaude profissionalDeSaude;
	    private String descricaoAtendimento;
	    private String tratamentoSugerido;
	    private List<Exame> examesSolicitados;
	    private String observacoes;
	    private Date dataDoCadastro;
	    private boolean status;
	    
//Construtor	    
	    public Prontuario(String identificador, Paciente paciente, ProfissionalSaude profissionalDeSaude,
                String descricaoAtendimento, String tratamentoSugerido, List<Exame> examesSolicitados,
                String observacoes) {
  this.identificador = identificador;
  this.paciente = paciente;
  this.profissionalDeSaude = profissionalDeSaude;
  this.descricaoAtendimento = descricaoAtendimento;
  this.tratamentoSugerido = tratamentoSugerido;
  this.examesSolicitados = examesSolicitados;
  this.observacoes = observacoes;
  this.dataDoCadastro = new Date();
  this.status = true;
}

// Getters e Setters
public String getIdentificador() {
  return identificador;
}

public void setIdentificador(String identificador) {
  this.identificador = identificador;
}

public Paciente getPaciente() {
  return paciente;
}

public void setPaciente(Paciente paciente) {
  this.paciente = paciente;
}

public ProfissionalSaude getProfissionalDeSaude() {
  return profissionalDeSaude;
}

public void setProfissionalDeSaude(ProfissionalSaude profissionalDeSaude) {
  this.profissionalDeSaude = profissionalDeSaude;
}

public String getDescricaoAtendimento() {
  return descricaoAtendimento;
}

public void setDescricaoAtendimento(String descricaoAtendimento) {
  this.descricaoAtendimento = descricaoAtendimento;
}

public String getTratamentoSugerido() {
  return tratamentoSugerido;
}

public void setTratamentoSugerido(String tratamentoSugerido) {
  this.tratamentoSugerido = tratamentoSugerido;
}

public List<Exame> getExamesSolicitados() {
  return examesSolicitados;
}

public void setExamesSolicitados(List<Exame> examesSolicitados) {
  this.examesSolicitados = examesSolicitados;
}

public String getObservacoes() {
  return observacoes;
}

public void setObservacoes(String observacoes) {
  this.observacoes = observacoes;
}

public Date getDataDoCadastro() {
  return dataDoCadastro;
}

public boolean isStatus() {
  return status;
}

public void setStatus(boolean status) {
  this.status = status;
}
	    
}
